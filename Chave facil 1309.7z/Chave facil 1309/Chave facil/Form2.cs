﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Chave_facil
{
    public partial class Form2 : Form
    {
        public static string nomefr2;
        public Form2()
        {
            InitializeComponent();
        }

        public void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        public void button1_Click(object sender, EventArgs e)
        {
            string nomefr2 = textBox1.Text;
            MessageBox.Show(nomefr2);
            this.Close();
        }
    }
}
