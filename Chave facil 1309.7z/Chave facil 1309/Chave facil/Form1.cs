﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.NetworkInformation;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Chave_facil
{

    public partial class Form1 : Form
    {
        string senha1;

        public Form1()
        {
            InitializeComponent();
            Form2 form2 = new Form2();  

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }


        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void btdevolver1_Click(object sender, EventArgs e)
        {


            

            if (senha1 == textBox2.Text) 
            { 
            BtRetirar2.Enabled = true;
            btdevolver1.Enabled = false;
            PnSala01.BackColor = Color.FromArgb(0,192,0);
            TxttNome.Text = null;
            Txtdate01.Text = null;
            MessageBox.Show("Sala Devolvida");
            TxttNome.Text = null;
             }
            else 
            {
                MessageBox.Show("Senha invalida");
            }

        }

        public void BtRetirar2_Click(object sender, EventArgs e)
        {
            string data1 = DtdateTime1.Text;
            string nome1 = textBox1.Text;
            senha1 = textBox2.Text;
            
            textBox1.Text = null;
            textBox2.Text = null;
            Txt_Digite.Text = "Digite o nome do locador";

            Retirar_Chaves();



            //(nome1);       
        }

        private void PnSala01_Click(object sender, EventArgs e)
        {
            
        }

        private void DtdateTimePicker1_ValueChanged(object sender, EventArgs e)
        {


        }

        private void DtdateTime1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void TxttNome_Click(object sender, EventArgs e)
        {

        }

        private void Txt_Digite_Click(object sender, EventArgs e)
        {

        }

        private void Txtgravar_Click(object sender, EventArgs e)
        {

        }
        private void Retirar_Chaves(Button devolver, Button retirar, Panel janela) 
        {
            devolver.Enabled = true;
            retirar.Enabled = false;
            janela.BackColor = Color.Red;
            Form2 form2 = new Form2();  
            form2.ShowDialog();
            string Nomefn = Form2.nomefr2;

            


        }
    }
}
