﻿using System;

public class RetirarSala
{
	public RetirarSala()
	{
		public string nome;
	
		public void Gravar() 
		{
			RetirarSala retirarSala = new RetirarSala();
			retirarSala.nome = Console.ReadLine();








    }
}
}
